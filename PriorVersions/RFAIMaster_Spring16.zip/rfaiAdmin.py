# Script to administrate RFAI database
# last revision: Feb 2016, Katherine Rothe + Michael Fruhnert

## PYTHON 2 SYNTAX WAS USED BECAUSE THE OPENPYXL LIBRARY WAS ONLY
## DEVELOPED FOR PYTHON 2

## INSTRUCTIONS:
## 1)  use along with rfai.py and rfaitoolbox.py


#import all necessary libraries
from openpyxl import load_workbook
from os import system
from rfaitoolbox import selectQuestionMaster, rearrangeCategories, checkMac
from rfaitoolbox import replaceQuestion, collectRFAI, normalizeMaster

# modify question
# modify category

teamTotal = -1 # total number of teams

doMore = True
system('clear')
checkMac()
while(doMore):
    print('This is the RFAI administration tool. ' \
            'Use with extreme caution!\n')

    doThis = raw_input("Choose from options below:\n"\
                "c: re-arrange categories\n" \
                "q: modify questions / answers\n" \
                "n: normalize master (ASCII conformity)\n" \
                "r: replace question (mark for deletion)\n" \
                "w: collect files and write responses\n" \
                "0: exit\n" \
                "\n")
    
    system('clear')
    if (doThis == 'c'):
        rearrangeCategories()
    elif (doThis == 'q'):
        selectQuestionMaster()
    elif (doThis == 'n'):
        normalizeMaster()
    elif (doThis == 'r'):
        while (teamTotal < 0): # retrieve teamTotal when needed
            teamTotal = int(raw_input("Enter total number of teams: "))
        rfaiNum = int(raw_input("Enter RFAI (1, 2, ...) in question: "))
        replaceQuestion(rfaiNum, teamTotal)
    elif (doThis == 'w'):
        while (teamTotal < 0): # retrieve teamTotal when needed
            teamTotal = int(raw_input("Enter total number of teams: "))
        rfaiNum = int(raw_input("Enter RFAI (1, 2, ...) in question: "))
        collectRFAI(rfaiNum, teamTotal)
    elif (doThis == '0'):
        print("RFAI administration tool shut-down...\n")
        doMore = False
    else:
        print("Invalid input. Enter 0 to exit.\n")
