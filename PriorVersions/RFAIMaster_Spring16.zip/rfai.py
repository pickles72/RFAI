#! /usr/local/bin/python2

# Script to stream-line RFAI processing
# last revision: Feb 2016, Katherine Rothe + Michael Fruhnert
# EDIT, FEB 23, 2016. Geoff Brown. Added a shebang because I hate typing 'python'

## PYTHON 2 SYNTAX WAS USED BECAUSE THE OPENPYXL LIBRARY WAS ONLY
## DEVELOPED FOR PYTHON 2

## INSTRUCTIONS:
## 1)  Place RFAIMaster folder into the Grade Entry (like a regular assignment
## 2a) The file with the RFAI questions and answers (defined by variable 'name'),
##      is formatted with 2 sheets with names: questions and categories
## 2b) The first column of the question sheet contains the question ID (QID)
##      in the form (Q##). QID are NOT to be altered
##      The second column contains the associated text (the question)
##      All following columns contain flavours of the same question
## 2c) The first column of the categories sheet contains the categories (text)
##     The second and following columns contain the associated QID
##     QIDs can be assigned to multiple categories
## 3)  To run, navigate to the appropriate folder and type 'python2 rfai.py' in
##      in the command prompt
##      Follow the subsequent prompts to operate the program.
## 4)  To change global variables, like the database name, go to rfaitoolbox.py


#import all necessary libraries
from openpyxl import load_workbook
from os import system
from rfaitoolbox import retrieveRubric, checkRubric, displayRubric, editQuestion
from rfaitoolbox import checkMac
        
system("clear") # clears previous inputs
#getrfai number
# rfaiNum = int(raw_input("Enter RFAI number: "))
rfaiNum = 3 # set default for each round
print 'RFAI ' + str(rfaiNum) + ' entry launched.'
checkMac()

while 1:
    teamNum = int(raw_input("Enter team number XX (0 to exit): "))
    if teamNum == 0:
        break
        
    rubric = retrieveRubric(rfaiNum, teamNum)
    if (rubric == ''):
        print '\nTeam not found. Check if team actually submit.\n'
        continue
    else:
        system('clear')
        checkRubric(rubric)
        wb = load_workbook(rubric)
        ws = wb.active
        
    moreqs = True
    while(moreqs):
        displayRubric(ws, rfaiNum)
        doThis = raw_input("Enter question to edit (1, 2, ...) or\n" \
                    "0: return\n" \
                    "f: change finish mark\n" \
                    "\n")
        
        system("clear")
        if (doThis == 'f'):
            wb = load_workbook(rubric) # pull most recent version
            ws = wb.active
            ws['ZZ1'].value = not(ws['ZZ1'].value == True)
            wb.save(rubric)
        else:
            if (doThis.isdigit()):
                doThis = int(doThis)
            else:
                doThis = -1
                
            if ((doThis > 0) and (doThis < 6)):
                ws = editQuestion(rubric, ws, doThis)
            elif (doThis == 0):
                moreqs = False
            else:
                print("Invalid input. Enter c to cancel.\n")

print("RFAI-Tool shut-down...")
